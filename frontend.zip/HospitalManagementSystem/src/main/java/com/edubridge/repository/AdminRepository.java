package com.edubridge.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edubridge.model.Admin;
@Repository
public interface AdminRepository extends JpaRepository<Admin,Long> 
{
	//Optional<Admin> findByEmailIdAndPassword(String emailId,String password);

	//Admin findAllById(long adminId);

	//List<Admin> findAllById(Admin adminId);

	//List<Admin> add(Admin admin);

	
	Admin findByEmailIdAndPassword(String emailId,String password);
	
	

}
