package com.edubridge.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edubridge.model.Doctor;
@Repository
public interface DoctorRepository extends JpaRepository<Doctor,Integer> {

	//Doctor createDoctorDetails(Doctor doctor);

	//Doctor updateDoctorDetails(Doctor doctor);


}
