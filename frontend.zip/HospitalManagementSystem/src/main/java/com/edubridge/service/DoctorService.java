package com.edubridge.service;



import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.model.Doctor;
//import com.edubridge.repository.DoctorRepository;

@Service
public interface DoctorService {

	Doctor addDoctor(Doctor doctor);
	Doctor updateDoctor(Doctor doctor, int doctor_id);
    List<Doctor> getAllDoctors();
	
	
}
