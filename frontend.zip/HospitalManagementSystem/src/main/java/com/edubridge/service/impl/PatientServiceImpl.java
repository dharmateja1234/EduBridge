package com.edubridge.service.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.model.Doctor;
import com.edubridge.model.Patient;
import com.edubridge.repository.PatientRepository;
import com.edubridge.service.PatientService;

@Service
public class PatientServiceImpl implements PatientService {
@Autowired

private PatientRepository patientRepository;

public PatientServiceImpl(PatientRepository patientRepository)
{
super();
this.patientRepository= patientRepository;
}
  public Patient addPatient(Patient patient) {
	// TODO Auto-generated method stub
	return patientRepository.save(patient);
  }	
	@Override
	public Object update(Long pid, Patient patient) {
		// TODO Auto-generated method stub
		return patientRepository;
	}

	@Override
	public Object delete(Long pid) {
		// TODO Auto-generated method stub
		return patientRepository;
	}

	@Override
	public List<Patient> getAllPatients() {
		// TODO Auto-generated method stub
		return patientRepository.findAll();
	}
	

	
}
