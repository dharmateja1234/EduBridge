package com.edubridge.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.model.Doctor;
import com.edubridge.service.DoctorService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class DoctorController {

	@Autowired
	private DoctorService doctorService;
	
	@PostMapping("/createDoctorDetails")
    public Doctor createDoctorDetails(@RequestBody Doctor doctor) {
        return doctorService.addDoctor(doctor);
    }
		
	@PutMapping("/updateDoctorDetails")
	public Doctor updateDoctorDetails(@RequestBody Doctor doctor) {
	return 	doctorService.updateDoctor(doctor, 1);
	}
	
	@GetMapping("/getDoctors")
	public List<Doctor> getAllDoctor(){
		return doctorService.getAllDoctors();
	}
}
