import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Patient } from '../patient';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-add-patient',
  templateUrl: './add-patient.component.html',
  styleUrls: ['./add-patient.component.css']
})
export class AddPatientComponent implements  OnInit{
  patient=new Patient(0,'',0,'','', 0,0,'');
  constructor(private route :Router,private patientService :PatientService){}
  ngOnInit(): void {
  
}
patientForm(){
  alert("Patient Added successfully");
  this.patientService.addpatient(this.patient).subscribe(data=>{console.log("Data save successfully"),
  this.route.navigate(['/view-patient']);
});
}
}
