import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Doctor } from '../doctor';
@Component({
  selector: 'app-doctor-login',
  templateUrl: './doctor-login.component.html',
  styleUrls: ['./doctor-login.component.css']
})
export class DoctorLoginComponent implements OnInit{
  doctor=new Doctor(0,'','','','','', '','','');
  constructor(private router:Router,private route:Router)

  {}
  ngOnInit(): void {
    
  }
  loginDoctor(){}
    
    /* this.registrationService .loginUserFromRemote(this.admin).subscribe(

      data =>{ console.log("response recieved"+data),
      this.router.navigate(['\adminhomepage'])},
      error=> console.log("exception occured" +error)
           )
        } */
}
