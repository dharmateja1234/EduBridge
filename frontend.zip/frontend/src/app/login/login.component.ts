import { Component,OnInit } from '@angular/core';
import {NgForm } from '@angular/forms';
import { RegistrationService } from '../registration.service';
import { Admin } from '../admin';
import { Router } from '@angular/router';
import { AdminhomepageComponent } from '../adminhomepage/adminhomepage.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{  
 admin =new Admin(0,"","","","");
  constructor(private registrationService : RegistrationService,private router:Router,private route:Router)

  {}
  ngOnInit() {
    }
    
    loginAdmin(){
    
      this.registrationService .loginUserFromRemote(this.admin).subscribe(

        data =>{ console.log("response recieved"+data),
        this.router.navigate(['\adminhomepage'])},
        error=> console.log("exception occured" +error)
             )
          }
          goBack()
          {
            this.route.navigate(['/'])
          }  
}
