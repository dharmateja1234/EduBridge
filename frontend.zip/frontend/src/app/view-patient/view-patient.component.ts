import { Component,OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { PatientService } from '../patient.service';
@Component({
  selector: 'app-view-patient',
  templateUrl: './view-patient.component.html',
  styleUrls: ['./view-patient.component.css']
})
export class ViewPatientComponent implements OnInit {
  patientList:any
  constructor(private patientService:PatientService,private router :Router){}
  ngOnInit(): void {
  this.patientService.getAllPatient().subscribe
  (
    data =>this.patientList=data,
    );
}
}
