import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { NavigationComponent } from './navigation/navigation.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { PatientComponent } from './patient/patient.component';
import { DoctorComponent } from './doctor/doctor.component';
import { AdminhomepageComponent } from './adminhomepage/adminhomepage.component';
import { RegistrationComponent} from './registration/registration.component';
import { AddDoctorComponent } from './add-doctor/add-doctor.component';
import { AddPatientComponent } from './add-patient/add-patient.component';
import { ViewDoctorComponent } from './view-doctor/view-doctor.component';
import { ViewPatientComponent } from './view-patient/view-patient.component';
const routes: Routes = [
  {path:'',component:WelcomeComponent},
  {path:'adminlogin',component:LoginComponent},

  {path:'adminhomepage',
  component:AdminhomepageComponent},
    {path:'add-doctor' , component:AddDoctorComponent},
    {path:'add-patient' , component:AddPatientComponent},
    {path:'view-doctor' , component:ViewDoctorComponent},
    {path:'view-patient' , component:ViewPatientComponent},

  {path:'doctor',component:DoctorComponent},
  {path:'patient',component:PatientComponent},
  
  {path:'registration',component:RegistrationComponent},
  {path:'',component:NavigationComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
