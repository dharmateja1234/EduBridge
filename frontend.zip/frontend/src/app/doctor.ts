export class Doctor {
    doctor_id:number;
    name: string;
	address: string;
	email : string;
	gender : string;
    phoneNumber:string;
    qualification:string;
    specialist:string;
    password:string;

    constructor(doctor_id:number,name: string,
        address: string,
        email : string,
        gender : string,
        phoneNumber:string,
        qualification:string,
        specialist:string, 
        password:string
    ) 
{
    this.doctor_id=doctor_id;
    this.name=name;
    this.address=address;
    this.email=email;
    this.gender=gender;
    this.phoneNumber=phoneNumber;
    this.qualification=qualification;
    this.specialist=specialist;
    this.password=password;
}
}