export class Doctor {
    doctor_id:number;
    name: string;
	address: string;
	email : string;
	gender : string;
    phonenumber:number;
    qualification:string;
    specialist:string;

    constructor(doctor_id:number,name: string,
        address: string,
        email : string,
        gender : string,
        phonenumber:number,
        qualification:string,
        specialist:string,
    ) 
{
    this.doctor_id=doctor_id;
    this.name=name;
    this.address=address;
    this.email=email;
    this.gender=gender;
    this.phonenumber=phonenumber;
    this.qualification=qualification;
    this.specialist=specialist;
    
}
}