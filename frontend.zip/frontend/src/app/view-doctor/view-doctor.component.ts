import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DoctorService } from '../doctor.service';

@Component({
  selector: 'app-view-doctor',
  templateUrl: './view-doctor.component.html',
  styleUrls: ['./view-doctor.component.css']
})
export class ViewDoctorComponent implements OnInit{

  doctorList:any
  constructor(private route :Router ,private doctorService:DoctorService,private router :Router){}
  ngOnInit(): void {
  this.doctorService.getAllDoctor().subscribe
  (
    data =>this.doctorList=data,
    );
}
goBack()
{
  this.route.navigate(['/adminhomepage'])
}
edit()
{
  this.route.navigate(['/adminhomepage'])
}
delete()
{
  this.route.navigate(['/adminhomepage'])
}
}
