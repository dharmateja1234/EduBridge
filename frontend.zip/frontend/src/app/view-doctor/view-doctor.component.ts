import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DoctorService } from '../doctor.service';

@Component({
  selector: 'app-view-doctor',
  templateUrl: './view-doctor.component.html',
  styleUrls: ['./view-doctor.component.css']
})
export class ViewDoctorComponent implements OnInit{

  doctorList:any
  constructor(private doctorService:DoctorService,private router :Router){}
  ngOnInit(): void {
  this.doctorService.getAllPatient().subscribe
  (
    data =>this.doctorList=data,
    );
}

}
