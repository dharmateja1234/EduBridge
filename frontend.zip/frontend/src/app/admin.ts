export class Admin {
    adminId :number;
    firstName: string;
	lastName: string;
	emailId : string;
	password : string;

    constructor(adminId:number,firstName:string,lastName:string,emailId:string,password:string) 
{
    this.adminId=adminId;
    this.firstName=firstName;
    this.lastName=lastName;
    this.emailId=emailId;
    this.password=password;
}

}
