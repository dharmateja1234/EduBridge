import { Component,OnInit } from '@angular/core';
import { Patient } from '../patient';
import { Router } from '@angular/router';
@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit{
  patient =new Patient(0,"",0,"","",'','');
  constructor(private route :Router,private router:Router) { }
 
 ngOnInit(): void {}
 
 
 patientRegister(){
  alert("Register Successfully");
  this.router.navigate(['\patienthomepage']);
}
goBack()
{
  this.route.navigate(['/'])
}
}
