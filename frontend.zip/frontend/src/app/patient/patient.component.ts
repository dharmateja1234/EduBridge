import { Component,OnInit } from '@angular/core';
import { Patient } from '../patient';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit{
  patient =new Patient(0,"",0,"","",0,0,"");
  constructor(){}
 
 ngOnInit(): void {}
 
 
 patientRegister(){
  alert("the page is click");
}
}
