export class Patient{
    pid:number;
    name:string;
    birthdate:number;
    gender:string;
    emailID:string;
    mobileNo:string;
    address:string;
     
    constructor(pid:number,name:string,birthdate:number,gender:string,emailID:string,mobileNo:string,
        address:string)

        {
            this.pid=pid;
            this.name=name;
            this.birthdate=birthdate;
            this.gender=gender;
            this.emailID=emailID;
            this.mobileNo=mobileNo;
            this.address=address;
        }

}