export class Patient{
    pid:number;
    name:string;
    birthdate:number;
    gender:string;
    emailID:string;
    mobileNo:number;
    adharNo:number;
    address:string;
     
    constructor(pid:number,name:string,birthdate:number,gender:string,emailID:string,mobileNo:number,adharNo:number,
        address:string)

        {
            this.pid=pid;
            this.name=name;
            this.birthdate=birthdate;
            this.gender=gender;
            this.emailID=emailID;
            this.mobileNo=mobileNo;
            this.adharNo=adharNo;
            this.address=address;
        }

}