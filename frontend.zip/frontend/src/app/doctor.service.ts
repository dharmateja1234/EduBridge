import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Doctor } from './doctor';
@Injectable({
  providedIn: 'root'
})
export class DoctorService {

  constructor(private http:HttpClient) { }
  public addDoctor(doctor:Doctor)
  {
    console.log("service");
    return this.http.post('http://localhost:8080/createDoctorDetails',doctor,{responseType:'Json' as 'text'});
  }
  public getAllPatient(){
    return this.http.get('http://localhost:8080/getDoctors');
  }
}
