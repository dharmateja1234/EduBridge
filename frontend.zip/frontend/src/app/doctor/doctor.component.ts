import { Component,OnInit } from '@angular/core';
import { DoctorService } from '../doctor.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit{
  doctorList:any
  constructor(private route :Router,private doctorService:DoctorService,private router :Router){}
  ngOnInit(): void {
  this.doctorService.getAllDoctor().subscribe
  (
    data =>this.doctorList=data,
    );
}
goBack()
{
  this.route.navigate(['/'])
}
}
