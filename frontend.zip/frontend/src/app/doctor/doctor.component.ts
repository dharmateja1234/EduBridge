import { Component,OnInit } from '@angular/core';
import { DoctorService } from '../doctor.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit{
  doctorList:any
  constructor(private doctorService:DoctorService,private router :Router){}
  ngOnInit(): void {
  this.doctorService.getAllPatient().subscribe
  (
    data =>this.doctorList=data,
    );
}
}
