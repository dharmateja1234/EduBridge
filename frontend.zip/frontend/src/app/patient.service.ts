import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Patient } from './patient';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor(private http:HttpClient) { }
  public addpatient(patient:Patient)
  {
    console.log("service");
    return this.http.post('http://localhost:8080/createPatientDetails/',patient,{responseType:'Json' as 'text'});
  }
  public getAllPatient(){
    return this.http.get('http://localhost:8080/getPatients');
  }
}
