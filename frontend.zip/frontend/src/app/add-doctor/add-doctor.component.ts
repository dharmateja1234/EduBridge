import { Component,OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Doctor } from '../doctor';
import { DoctorService } from '../doctor.service';
@Component({
  selector: 'app-add-doctor',
  templateUrl: './add-doctor.component.html',
  styleUrls: ['./add-doctor.component.css']
})
export class AddDoctorComponent implements OnInit{
doctor=new Doctor(0,'','','','','', '','','');
  constructor(private route :Router,private doctorService :DoctorService){}
  ngOnInit(): void {   
  }
  addForm=new FormGroup({

  });
  registerForm(){
    alert("Doctor Added successfully");
    this.doctorService.addDoctor(this.doctor).subscribe(data=>{console.log("Data save successfully"),
    this.route.navigate(['/view-doctor']);
  });
  }
  goBack()
  {
    this.route.navigate(['/adminhomepage'])
  }
}
