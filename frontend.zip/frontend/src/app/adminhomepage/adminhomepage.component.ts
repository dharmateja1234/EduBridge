import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminhomepage',
  templateUrl: './adminhomepage.component.html',
  styleUrls: ['./adminhomepage.component.css']
})
export class AdminhomepageComponent implements OnInit {
   
constructor(private route :Router) { }
ngOnInit(): void {
  
}

addDoctor()
{
  this.route.navigate(['/addDoctor'])
}
addPatient()
{
  this.route.navigate(['/addPatient'])
}
viewDoctor()
{
  this.route.navigate(['/viewDoctor'])
}
viewPatient()
{
  this.route.navigate(['/viewPatient'])
}

goBack()
{
  this.route.navigate(['/viewPatient'])
}
}

