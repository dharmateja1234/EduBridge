import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './admin';
import {HttpClient} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private http:HttpClient) { }  
  public loginUserFromRemote(admin:Admin):Observable<any>
  {
    console.log("loginAdmin service");
     return this.http.post("http://localhost:8080/api/admin/login",admin,{responseType:'json' as 'text'})
  }
}
