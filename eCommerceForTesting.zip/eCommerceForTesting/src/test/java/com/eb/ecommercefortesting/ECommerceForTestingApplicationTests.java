package com.eb.ecommercefortesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceForTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
