package com.eb.ecommercefortesting.service;

import java.util.List;
import org.springframework.web.bind.annotation.PathVariable;

import com.eb.ecommercefortesting.model.Payement;

public interface PayementService {
	Payement addPayement(Payement payement,long customerId, long productId);
	List<Payement> getAllPayements();
	Payement getPayementById(long id);
	void deletePayement(long id);
}
