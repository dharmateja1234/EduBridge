package com.eb.ecommercefortesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommerceForTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommerceForTestingApplication.class, args);
	}

}
