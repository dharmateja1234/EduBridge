package com.eb.ecommercefortesting.exception;

public class AdminNotFoundException {

}
