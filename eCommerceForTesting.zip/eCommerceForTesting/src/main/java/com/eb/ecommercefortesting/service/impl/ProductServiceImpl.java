package com.eb.ecommercefortesting.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eb.ecommercefortesting.exception.ProductNotFoundException;
import com.eb.ecommercefortesting.model.Customer;
import com.eb.ecommercefortesting.model.Product;
import com.eb.ecommercefortesting.repository.ProductRepository;
import com.eb.ecommercefortesting.service.ProductService;


@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	//private PlaceService placeService;

	
	public ProductServiceImpl(ProductRepository productRepository) {
		super();
		this.productRepository = productRepository;
	}



	@Override
	public Product addProduct(Product product) {

		//Place place=placeService.getPlaceById(placeId);
		//product.setPlace(place);
		return productRepository.save(product);
	}



	@Override
	public Product getProductById(long id) {
		
		return productRepository.findById(id).orElseThrow(()->new ProductNotFoundException("Product","Id",id));
	}



	@Override
	public Product updateProduct(Product product, long id) {
		Product existingProduct=productRepository.findById(id).orElseThrow(()->new ProductNotFoundException("Product","Id",id));
		existingProduct.setProductName(product. getProductName());
		

		existingProduct.setImage(product. getImage());
		existingProduct.setProductDetails(product. getProductDetails());

		
		productRepository.save(existingProduct);
		return existingProduct;
	}



	@Override
	public void deleteProduct(long id) {
		productRepository.findById(id).orElseThrow(()->new ProductNotFoundException("Product","Id",id));
		productRepository.deleteById(id);
		
	}
	@Override
	public List<Product> getAllProducts() {
	
		return productRepository.findAll();
	}

	
}
