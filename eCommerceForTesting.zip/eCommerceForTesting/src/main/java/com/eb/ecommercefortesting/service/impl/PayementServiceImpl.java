package com.eb.ecommercefortesting.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eb.ecommercefortesting.exception.PayementNotFoundException;
import com.eb.ecommercefortesting.model.Customer;
import com.eb.ecommercefortesting.model.Payement;
import com.eb.ecommercefortesting.model.Product;
import com.eb.ecommercefortesting.repository.PayementRepository;
import com.eb.ecommercefortesting.service.CustomerService;
import com.eb.ecommercefortesting.service.PayementService;
import com.eb.ecommercefortesting.service.ProductService;



@Service
public class PayementServiceImpl implements PayementService{
	@Autowired
	private PayementRepository payementRepository;
	
	@Autowired
	private CustomerService customerService;
	
	private ProductService productService;


        public PayementServiceImpl(PayementRepository payementRepository,CustomerService customerService,ProductService productService) {
			super();
			this.payementRepository = payementRepository;
			this.customerService = customerService;
			this.productService = productService;
	
		}

    @Override
	public Payement addPayement(Payement payement,long customerId,long productId) {
		// TODO Auto-generated method stub
	Product product=productService.getProductById(productId);
	payement.setProductName(product.getProductName());
	Customer customer=customerService.getCustomerById(customerId);
	payement.setFirstName(customer.getFirstName());
	payement.setLastName(customer.getLastName());
	payement.setEmailID(customer.getEmailID());
	payement.setDistrict(customer.getDistrict());
	payement.setState(customer.getState());	
	payement.setZipCode(customer.getZipCode());
	payement.setCustomer(customer);
	     return payementRepository.save(payement);
	}



	@Override
	public List<Payement> getAllPayements() {
		return payementRepository.findAll();
	}
	


	@Override
	public Payement getPayementById(long id) {
		
		return payementRepository.findById(id).orElseThrow(()->new PayementNotFoundException("Payement","Id",id));
	}


    @Override
	public void deletePayement(long id) {
		payementRepository.findById(id).orElseThrow(()->new PayementNotFoundException("Facilities","Id",id));
		payementRepository.deleteById(id);
		
	}
	
}

