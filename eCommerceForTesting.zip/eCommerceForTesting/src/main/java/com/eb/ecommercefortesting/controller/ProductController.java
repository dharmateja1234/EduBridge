package com.eb.ecommercefortesting.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eb.ecommercefortesting.model.Customer;
import com.eb.ecommercefortesting.model.Product;
import com.eb.ecommercefortesting.service.ProductService;


@CrossOrigin(origins="http://localhost:4200")

@RestController  
@RequestMapping("/api/products")
public class ProductController {

	@Autowired
	private ProductService productService;

	public ProductController(ProductService productService) {
		super();
		this.productService = productService;
	}
	
//to add products "{placeId}"
	@PostMapping("/register")
	public ResponseEntity<Product> addProduct(@Valid @RequestBody Product product)
	{
		System.out.println("********************");
			return new ResponseEntity<Product>(productService.addProduct(product),HttpStatus.CREATED);
	}
	
	//to get all Product details
	//Get All Customer	
	@GetMapping("/all")
	public List<Product> getAllProducts()
	{
		return productService.getAllProducts();
	}
	//update Product
	@PutMapping("{id}")
	public ResponseEntity<Product> updateProduct(@Valid @PathVariable("id") long id, @RequestBody Product product)
	{
		return new ResponseEntity<Product> (productService.updateProduct(product, id),HttpStatus.OK);
	}
	//delete Product
	@DeleteMapping("{id}")
	public ResponseEntity<Boolean> deleteProduct(@PathVariable long id)
	{
		productService.deleteProduct(id);
		boolean flag=true;
		return new ResponseEntity<Boolean>(flag,HttpStatus.OK);
	}
}
