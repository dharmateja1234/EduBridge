package com.eb.ecommercefortesting.model;

import java.sql.Date;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="payement_table")
public class Payement {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private long payementId;

@Column(name="total_price")
private  int totalPrice;

@Column(name="first_name")
private String firstName;

@Column(name="last_name")
private String lastName;

@Column(name="district")
private String district;

@Column(name="state")
private String state;

@Column(name="zip_code")
private String zipCode;

@Column(name="email_id")
public String emailID;

@Column(name="name_on_card")
@NotEmpty
@Size(min=3 , message="name must contain atleast 3 characters")
private String nameOnCard;

@Column(name="card_number")
@NotEmpty
@Size(min=16 , max=16,message="cardNumber must contain 16 digits")
private String cardNumber;

@Column(name="exp_year")
private String expYear;

@Column(name="cvv")
@NotNull
private int cvv;

@Column(name="product_name")
private String productName;

@Column(name="paid_date")
private String paidDate;

@ManyToOne( cascade=CascadeType.MERGE)
@JoinColumn(name="customer__id")
@JsonIgnore
private Customer customer;

public long getPayementId() {
	return payementId;
}

public void setPayementId(long payementId) {
	this.payementId = payementId;
}

public int getTotalPrice() {
	return totalPrice;
}

public void setTotalPrice(int totalPrice) {
	this.totalPrice = totalPrice;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getDistrict() {
	return district;
}

public void setDistrict(String district) {
	this.district = district;
}

public String getState() {
	return state;
}

public void setState(String state) {
	this.state = state;
}

public String getZipCode() {
	return zipCode;
}

public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
}

public String getEmailID() {
	return emailID;
}

public void setEmailID(String emailID) {
	this.emailID = emailID;
}

public String getNameOnCard() {
	return nameOnCard;
}

public void setNameOnCard(String nameOnCard) {
	this.nameOnCard = nameOnCard;
}

public String getCardNumber() {
	return cardNumber;
}

public void setCardNumber(String cardNumber) {
	this.cardNumber = cardNumber;
}

public String getExpYear() {
	return expYear;
}

public void setExpYear(String expYear) {
	this.expYear = expYear;
}

public int getCvv() {
	return cvv;
}

public void setCvv(int cvv) {
	this.cvv = cvv;
}

public String getProductName() {
	return productName;
}

public void setProductName(String productName) {
	this.productName = productName;
}

public String getPaidDate() {
	return paidDate;
}

public void setPaidDate(String paidDate) {
	this.paidDate = paidDate;
}

public Customer getCustomer() {
	return customer;
}

public void setCustomer(Customer customer) {
	this.customer = customer;
}


}
