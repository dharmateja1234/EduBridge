package com.edubridge.service;

import java.util.List;

import com.edubridge.model.Admin;

public interface AdminService {
    Admin loginAdmin(Admin admin);
 	Admin saveAdmin(Admin admin);
	Admin getAdminById(long adminId);
	List<Admin> getAllAdmin();
	
	

}
