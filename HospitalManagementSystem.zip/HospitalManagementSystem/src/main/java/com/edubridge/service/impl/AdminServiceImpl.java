package com.edubridge.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.model.Admin;
import com.edubridge.repository.AdminRepository;
import com.edubridge.service.AdminService;
@Service
public class AdminServiceImpl implements AdminService {
@Autowired
private AdminRepository adminRepository;
public AdminServiceImpl(AdminRepository adminRepository) {
	super();
	this.adminRepository=adminRepository;
}
	@Override
	public Admin loginAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepository.findByEmailIdAndPassword(admin.getEmailId(),admin.getPassword());
	}

	@Override
	public Admin saveAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepository.save(admin);
	}
	
	
	@Override
	public Admin getAdminById(long adminId) {
		// TODO Auto-generated method stub
		return adminRepository.findById(adminId).get();
	}
	@Override
	public List<Admin> getAllAdmin() {
		// TODO Auto-generated method stub
		return adminRepository.findAll();
	}
				
}
