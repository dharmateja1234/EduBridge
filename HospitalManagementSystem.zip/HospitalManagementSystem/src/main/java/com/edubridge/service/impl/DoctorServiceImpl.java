package com.edubridge.service.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.edubridge.model.Doctor;
import com.edubridge.repository.DoctorRepository;
import com.edubridge.service.DoctorService;
@Service
public class DoctorServiceImpl implements DoctorService{

	@Autowired
	
	private DoctorRepository doctorRepository;
	
	public DoctorServiceImpl(DoctorRepository doctorRepository) {
		
		super();
		this.doctorRepository=doctorRepository;
	}

	@Override
	public Doctor addDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		return doctorRepository.save(doctor);
	}

	@Override
	public Doctor updateDoctor(Doctor doctor, int doctor_id) {
		Doctor doctor1=doctorRepository.findById(doctor_id).get();
		doctor1.setEmail(doctor.getEmail());
		doctor1.setName(doctor.getName());		
		doctor1.setGender(doctor.getGender());
		doctor1.setPhoneNumber(doctor.getPhoneNumber());
        doctor1.setQualification(doctor.getQualification());
        doctor1.setSpecialist(doctor.getSpecialist());
       // Address address=doctor1.getAddress();
        doctor1.setAddress(doctor.getAddress());
        
		return doctorRepository.save(doctor);
	}

	@Override
	public List<Doctor> getAllDoctors() {
		
		return doctorRepository.findAll();
	}

	
}
