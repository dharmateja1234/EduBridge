package com.edubridge.service;


import java.util.List;

import com.edubridge.model.Doctor;
import com.edubridge.model.Patient;

public interface PatientService {
    Patient addPatient(Patient patient);
    
	Object update(Long pid, Patient patient);

	Object delete(Long pid);
    
	 List<Patient> getAllPatients();
	
}
