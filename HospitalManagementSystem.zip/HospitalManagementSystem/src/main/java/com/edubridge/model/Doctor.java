package com.edubridge.model;

import javax.persistence.Column;
import javax.persistence.Entity;
//import javax.persistence.EnumType;
//import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;

@Entity
@Table(name="Doctor_table")
public class Doctor {
	
	  @Id
	  @GeneratedValue(strategy=GenerationType.IDENTITY)
	  @Column(name="doctor_id")
	  private int doctor_id; 
	  
	  @Column(name="doctor_name")
	  private String name; 
	  
	  @Column(name="email_Id")
	  private String email;
	  
	  @Column(name="password")
	  private String password;
	  
	  @Column(name="address")
	  private String address;
	  
	  //@Enumerated(EnumType.ORDINAL) 
	  @Column(name="gender")
	  private String gender;
	  
	   
	  @Column(name="phone_number")
	  private long phoneNumber; 
	  
	  @Column(name="Qualification")
	  private String qualification;
	  
	  @Column(name="specialist")
	  private String specialist; 
	  
	@OneToMany(mappedBy="doctor", cascade=CascadeType.MERGE)
	@JsonIgnore  
	private Set<Patient> doctor=new HashSet<>();
	
	  
	
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getDoctor_id() {
		return doctor_id;
	}
	public void setDoctor_id(int doctor_id) {
		this.doctor_id = doctor_id;
	}
	
	  public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() 
	  { 
		  return email; 
		  } 
	  public void setEmail(String email) 
	  {
	  this.email = email; 
	  } 
	 
	  
	  public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Set<Patient> getDoctor() {
		return doctor;
	}
	public void setDoctor(Set<Patient> doctor) {
		this.doctor = doctor;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getPhoneNumber() 
	  { 
		  return phoneNumber; 
		  } 
	  public void setPhoneNumber(long
	  phoneNumber) 
	  { 
		  this.phoneNumber = phoneNumber; 
		  } 
	  public String getQualification() 
	  { 
		  return qualification; 
		  } 
	  public void setQualification(String qualification) 
	  { 
		  this.qualification = qualification;
	  } 
	  public String getSpecialist() 
	  { 
		  return specialist; 
		  } 
	  public void setSpecialist(String specialist) 
	  { 
		  this.specialist = specialist; 
		  } 
	 
	 
	 

}
