package com.edubridge.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="PatientTable")
public class Patient {
	@Id 
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pid") 
	  private Long pid;
	 // @NotEmpty
	  //@Size(min=3)
	  @Column(name="name") 
	  private String name;
	  
	  public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}


	@Column(name="birthdate") 
	  private String birthdate; 

	  @Column(name="gender") 
	  private String gender;
	  
	  @Column(name="emailID") 
	  private String emailID; 
	  
	  @Column(name="mobileNo") 
	  private String mobileNo;
	  
	  
	  @Column(name="address") 
	  private String address;
	  
	  
	  public Long getPid() {
		return pid;
	}
	public void setPid(Long pid) {
		this.pid = pid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}


	@ManyToOne
	  private Doctor doctor;
	  public Patient() 
	  { }
	public Patient(Long pid, String name, String birthdate, String gender, String emailID, String mobileNo,
			 String address, Doctor doctor) {
		super();
		this.pid = pid;
		this.name = name;
		this.birthdate = birthdate;
		this.gender = gender;
		this.emailID = emailID;
		this.mobileNo = mobileNo;
		this.address = address;
		this.doctor = doctor;
	}
	

}
