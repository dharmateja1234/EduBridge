package com.edubridge.repository;

public class PatientRepository {

}
