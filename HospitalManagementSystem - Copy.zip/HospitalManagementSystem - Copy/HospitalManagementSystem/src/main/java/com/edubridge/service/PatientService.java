package com.edubridge.service;

public class PatientService {

	public Object findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
