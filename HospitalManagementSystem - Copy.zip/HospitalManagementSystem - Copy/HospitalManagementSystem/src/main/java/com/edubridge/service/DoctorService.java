package com.edubridge.service;

public class DoctorService {

}
