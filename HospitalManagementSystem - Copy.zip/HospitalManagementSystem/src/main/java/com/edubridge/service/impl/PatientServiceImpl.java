package com.edubridge.service.impl;

public class PatientServiceImpl {

}
