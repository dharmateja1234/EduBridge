package com.edubridge.repository;

public class DoctorRepository {

}
