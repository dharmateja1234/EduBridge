package com.edubridge.repository;

public class AdminRepository {

}
