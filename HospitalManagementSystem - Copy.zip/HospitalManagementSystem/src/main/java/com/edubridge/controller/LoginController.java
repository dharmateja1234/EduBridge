package com.edubridge.controller;

public class LoginController {

}
